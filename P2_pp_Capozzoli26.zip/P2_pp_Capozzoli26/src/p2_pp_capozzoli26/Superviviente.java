package p2_pp_capozzoli26;

import java.util.Objects;

/**
 * @author Paula Capozzoli
 */
public abstract class Superviviente {
    private final String codigo;
    private final String nombre;
    private final NivelExperiencia nivel;
    private boolean disponible;

    public Superviviente(String codigo, String nombre, NivelExperiencia nivel, boolean disponible) {
        
        validarString(codigo, "El codigo no puede ser nulo ni estar vacio");
        validarString(nombre, "El nombre no puede ser nulo ni estar vacio");
        validarNivel(nivel);
                
        this.codigo = codigo;
        this.nombre = nombre;
        this.nivel = nivel;
        this.disponible = disponible;
    }
    
    private void validarString(String string, String mensaje){
        if(string == null || string.isBlank()){
            throw new IllegalArgumentException(mensaje);
        }
    }
    
    private void validarNivel(NivelExperiencia nivel){
        if(nivel == null){
            throw new IllegalArgumentException("El nivel de experiencia no puede ser nulo");
        }
    }
    
    public String getCodigo(){
        return codigo;
    }
    public String getNombre(){
        return nombre;
    }
    public NivelExperiencia getNivelExperiencia(){
        return nivel;
    }
    public boolean isDisponible(){
        return disponible;
    }
    
    public void ocupar(){
        this.disponible = false;
    }
    
    public abstract String getDescripcion();
    
    public abstract int calcularAptitud();
    
    /**
     * Personaliza la descripción de un objeto
     * @return Descripcion personalizada del metodo getDescripcion
     */
    @Override
    public String toString(){
        return getDescripcion();
    }
    
    /**
     * Personaliza la comparación de dos objetos por criterios especificos
     * @param objeto es el objeto a comparar
     * @return True si son iguales, false si son distintos
     */
    @Override
    public boolean equals(Object objeto){
        if(this == objeto){
            return true;
        }
        if (!(objeto instanceof Superviviente distinto)){
            return false;
        }
        return codigo.equals(distinto.codigo)&&nombre.equals(distinto.nombre);
    }
    
    /**
     * Personaliza los atributos con los que se asocia el identificador del objeto
     * @return identificador segun codigo y nombre
     */
    @Override
    public int hashCode() {
        return Objects.hash(codigo, nombre);
    }
}
