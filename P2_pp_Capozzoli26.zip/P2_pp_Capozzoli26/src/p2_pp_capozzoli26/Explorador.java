package p2_pp_capozzoli26;
/**
 * @author Paula Capozzoli
 */
public class Explorador extends Superviviente implements Asignable {
    private final int resistencia;
    
    public Explorador(String codigo, String nombre, NivelExperiencia nivel, boolean  disponible, int resistencia){
        super(codigo, nombre, nivel, disponible);
        validarResistencia(resistencia);
        this.resistencia = resistencia;
    }
    
    private void validarResistencia(int resistencia){
        if(resistencia < 1){
            throw new IllegalArgumentException("El valor de la resistencia no puede ser 0");
        }
    }
    
    public int getResistencia(){
        return resistencia;
    }
    
    /**
     * Sobreescribe el metodo abstracto de clase Superviviente para personalizar la descripcion de Explorador
     * @return descripcion de Explorador
     */
    @Override
    public String getDescripcion(){
        return "Explorador [codigo="+ getCodigo()+
               ", nombre="+ getNombre()+
               ", nivel="+ getNivelExperiencia()+
               ", disponible="+ isDisponible()+
               ", resistencia="+ getResistencia()+"]";
    }
    
    /**
     * Sobreescribe el metodo abstracto de clase Superviviente para calcular la resitencia de Explorador
     * @return valor de resistencia en un entero
     */
    @Override
    public int calcularAptitud(){
        return resistencia*2;
    }
    
    /**
     * Implementacion del metodo asignar de la interface Asignable
     * @param tarea es la descripcion de la tarea que se va a asignar
     * @return un mensaje descriptivo del Explorador al que se le asina la tarea
     */
    @Override
    public String asignar(String tarea){
        return "Se asigno a "+ getNombre() +" la tarea: "+ tarea +".";
    }
}
