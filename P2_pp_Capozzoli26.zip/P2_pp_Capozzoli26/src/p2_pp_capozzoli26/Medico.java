package p2_pp_capozzoli26;
/**
 * @author Paula Capozzoli
 */
public class Medico extends Superviviente implements Capacitable{
    private final int conocimiento;
    
    public Medico(String codigo, String nombre, NivelExperiencia nivel, boolean disponible, int conocimiento){
        super(codigo, nombre, nivel, disponible);
        validarConocimiento(conocimiento);
        this.conocimiento = conocimiento;
    }
    
    private void validarConocimiento(int conocimiento){
        if(conocimiento < 1){
            throw new IllegalArgumentException("El valor del conocimiento no puede ser 0");
        }
    }
    
    public int getConocimiento(){
        return conocimiento;
    }
    
    /**
     * Sobreescribe el metodo abstracto de clase Superviviente para personalizar la descripcion de Medico
     * @return descripcion de Constructor
     */
    @Override
    public String getDescripcion(){
        return "Medico [codigo="+ getCodigo()+
               ", nombre="+ getNombre()+
               ", nivel="+ getNivelExperiencia()+
               ", disponible="+ isDisponible()+
               ", conocimientos="+ getConocimiento() +"]";
    }
    
    /**
     * Sobreescribe el metodo abstracto de clase Superviviente para calcular la habilidad de Medico
     * @return valor de conocimiento en un entero
     */
    @Override
    public int calcularAptitud(){
        return conocimiento+10;
    }
    
    /**
     * Implementacion del metodo capacitar de la interface Capacitable
     * @return un mensaje descriptivo del Medico capacitado por nombre y codigo
     */
    @Override
    public String capacitar(){
        return "Se capacito a: "+ getNombre()+ " ("+ getCodigo()+").";
    }
}
