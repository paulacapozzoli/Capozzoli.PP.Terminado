package p2_pp_capozzoli26;

import java.util.List;
import java.util.Objects;

/**
 * @author Paula Capozzoli
 */
public class P2_pp_Capozzoli26 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Refugio refugio = new Refugio("Horizonte");
        
        try {
        refugio.agregarSuperviviente(new Explorador(
                "EXP-101", "Ada", NivelExperiencia.SENIOR, true, 30));
        refugio.agregarSuperviviente(new Medico(
                "MED-220", "Bruno", NivelExperiencia.INTERMEDIO, true, 45));
        refugio.agregarSuperviviente(new Constructor(
                "CON-330", "Carla", NivelExperiencia.SENIOR, true, 25));
        refugio.agregarSuperviviente(new Explorador(
                "EXP-404", "Diego", NivelExperiencia.JUNIOR, true, 18));
        refugio.agregarSuperviviente(new Medico(
                "EXP-101", "Ada", NivelExperiencia.JUNIOR, true, 12));
        } catch (SupervivienteDuplicadoException e){
            System.out.println("No se pudo registrar: " + e.getMessage());
        }
        System.out.println("Supervivientes registrados:");
        mostrarSupervivientes(refugio.obtenerSupervivientes());
        System.out.println("\nAptitudes:");
        mostrarAptitudes(refugio.obtenerSupervivientes());
        System.out.println("\nAsignacion de tareas:");
        asignarTareas(refugio.obtenerSupervivientes());
        System.out.println("\nCapacitaciones:");
        capacitarSupervivientes(refugio.obtenerSupervivientes());
        System.out.println("\nDisponibles con aptitud >= 50:");
        mostrarSupervivientes(refugio.obtenerDisponiblesConAptitudMinima(50));
        System.out.println("\nSupervivientes SENIOR:");
        mostrarSupervivientes(refugio.filtrarPorNivel(NivelExperiencia.SENIOR));
        
    }
    
    /**
     * Recibe una lista de supervivientes, valida que no este vacia y muestra 
     * cada superviviente de la lista recorriendo el arreglo
     * @param supervivientes lista de supervivientes
     */
    private static void mostrarSupervivientes(List<Superviviente> supervivientes) {
        if(supervivientes.isEmpty()){
            System.out.println("No hay supervivientes para mostrar.");
        }else{
            for(Superviviente superviviente : supervivientes){
                System.out.println(superviviente);
            }
        }
    }
    
    /**
     * Recibe una lista de supervivientes, valida que no este vacia y muestra
     * cada superviviente junto a su aptitud calculada recorriendo el arreglo
     * @param supervivientes lista de supervivientes por nombre y aptitud calculada
     */
    private static void mostrarAptitudes(List<Superviviente> supervivientes) {
        if(supervivientes.isEmpty()){
            System.out.println("No hay supervivientes para mostrar.");
        }else{
            for(Superviviente superviviente : supervivientes){
                System.out.println(superviviente.getNombre() + ": " + (int)superviviente.calcularAptitud());
            }
        }
    }
    
    /**
     * Asigna una tarea a un superviviente dejandolo no disponible para otra tarea
     * validando que no tenga una referencia null y comprobando que sea una instancia de Asignable
     * @param supervivientes lista de supervivientes
     */
    private static void asignarTareas(List<Superviviente> supervivientes) {
        for(Superviviente superviviente : supervivientes){
            Objects.requireNonNull(superviviente);
            if(superviviente instanceof Asignable asignable){
                System.out.println(asignable.asignar("Mision de apoyo"));
                superviviente.ocupar();
            }else{
                System.out.println(superviviente.getNombre() +" no puede recibir tareas.");
            }                    
        }
    }
    
    /**
     * Capacita a un superviviente, validando que no tenga una referencia null
     * y comprobando que sea una instancia de Capacitable
     * @param supervivientes lista de supervivientes 
     */
    private static void capacitarSupervivientes(List<Superviviente> supervivientes) {
        for(Superviviente superviviente : supervivientes){
            Objects.requireNonNull(superviviente);
            if(superviviente instanceof Capacitable capacitable){
                System.out.println(capacitable.capacitar());
            }else{
                System.out.println(superviviente.getNombre() + " no puede capacitarse.");
            }
        }
    }    
}
