package p2_pp_capozzoli26;

/**
 * @author Paula Capozzoli
 */
public enum NivelExperiencia {    
    JUNIOR,
    INTERMEDIO,
    SENIOR    
}
