package p2_pp_capozzoli26;

/**
 * @author Paula Capozzoli
 */
public interface Capacitable {
    String capacitar();
}
