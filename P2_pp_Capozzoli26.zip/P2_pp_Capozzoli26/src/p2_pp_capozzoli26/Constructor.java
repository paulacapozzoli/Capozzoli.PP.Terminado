package p2_pp_capozzoli26;

/**
 * @author Paula Capozzoli
 */
public class Constructor extends Superviviente implements Asignable, Capacitable{
    
    private final int habilidad;
    
    public Constructor (String codigo, String nombre, NivelExperiencia nivel, boolean  disponible, int  habilidad){
        super(codigo, nombre, nivel, disponible);
        validarHabilidad(habilidad);
        this.habilidad = habilidad;
    }
    
    private void validarHabilidad(int habilidad){
        if(habilidad < 1){
            throw new IllegalArgumentException("El valor de la habilidad no puede ser 0");
        }
    }
    
    public int getHabilidad(){
        return habilidad;
    }
    /**
     * Sobreescribe el metodo abstracto de clase Superviviente para personalizar la descripcion de Constructor
     * @return descripcion de Constructor
     */
    @Override
    public String getDescripcion(){
        return "Constructor [codigo="+ getCodigo()+
               ", nombre="+ getNombre()+
               ", nivel="+ getNivelExperiencia()+
               ", disponible="+ isDisponible()+
               ", habilidadTecnica="+ getHabilidad()+"]";
    }
    /**
     * Sobreescribe el metodo abstracto de clase Superviviente para calcular la habilidad de Constructor
     * @return valor de habilidad en un entero
     */
    @Override
    public int calcularAptitud(){
        return habilidad*3;
    }
    
    /**
     * Implementacion del metodo capacitar de la interface Capacitable
     * @return un mensaje descriptivo del Constructor capacitado por nombre y codigo
     */
    @Override
    public String capacitar(){
        return "Se capacito a: "+ getNombre()+ " ("+ getCodigo()+").";
    }
    
    /**
     * Implementacion del metodo asignar de la interface Asignable
     * @param tarea es la descripcion de la tarea que se va a asignar
     * @return un mensaje descriptivo del Constructor al que se le asina la tarea
     */
    @Override
    public String asignar(String tarea){
        return "Se asigno a "+ getNombre() +" la tarea: "+ tarea +".";
    }    
}
