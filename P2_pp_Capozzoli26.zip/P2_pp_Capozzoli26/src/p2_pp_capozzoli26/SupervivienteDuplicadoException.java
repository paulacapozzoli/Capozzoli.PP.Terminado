package p2_pp_capozzoli26;

/**
 * @author Paula Capozzoli
 */
public class SupervivienteDuplicadoException extends Exception{
    
    public SupervivienteDuplicadoException(String mensaje){
        super(mensaje);
    }
}
