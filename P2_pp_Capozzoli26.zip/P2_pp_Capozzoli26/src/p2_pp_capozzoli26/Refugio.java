package p2_pp_capozzoli26;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Paula Capozzoli
 */
public class Refugio {
    private final String nombre;
    private final List<Superviviente> supervivientes;
    
    public Refugio(String nombre){
        validarNombre(nombre);
        this.nombre = nombre;
        supervivientes = new ArrayList<>();
    }
    
    private void validarNombre (String nombre){
        if(nombre == null || nombre.isBlank()){
            throw new IllegalArgumentException("El nombre del refugio no puede estar vacio");
        }
    }
    
    public String getNombre(){
        return nombre;
    }
    /**
     * Agrega un objeto a la lista de supervivientes
     * 
     * @param superviviente objeto de tipo superviviente
     * @throws SupervivienteDuplicadoException lanza excepcion personalizada en caso de haber un duplicado
     */
    public void agregarSuperviviente(Superviviente superviviente) throws SupervivienteDuplicadoException{
        validarSuperviviente(superviviente);
        validarSupervivienteDuplicado(superviviente);
        supervivientes.add(superviviente);
    }
    private void validarSuperviviente(Superviviente superviviente){
        if(superviviente == null){
            throw new IllegalArgumentException("El superviviente no puede ser nulo");
        }
    }
    private void validarSupervivienteDuplicado(Superviviente superviviente) throws SupervivienteDuplicadoException {
        if(supervivientes.contains(superviviente)){
            throw new SupervivienteDuplicadoException("Ya existe un superviviente con codigo " +
                      superviviente.getCodigo()+" y nombre " + 
                      superviviente.getNombre()+"." );
        }
    }
    /**
     * Crea una lista de supervivientes
     * @return nueva lista "supervivientes"
     */
    public List<Superviviente> obtenerSupervivientes(){
        return new ArrayList<>(supervivientes);
    }
    /**
     * Filtra la lista de supervivientes por nivel y devuelve una nueva lista 
     * @param nivel es el criterio por el que se filtra
     * @return Nueva lista de supervivientes filtrados
     */
    public List<Superviviente> filtrarPorNivel(NivelExperiencia nivel){
        if(nivel == null){
            throw new IllegalArgumentException("El nivel de experiencia no puede ser nulo");
        }
        List<Superviviente> filtrados = new ArrayList<>();
        
        for(Superviviente superviviente : supervivientes){
            if(superviviente.getNivelExperiencia() == nivel){
                filtrados.add(superviviente);
            }
        }
        return filtrados;
    }
    /**
     * Filtra la lista de supervivientes disponibles con aptitud mínima
     * validando que no sea menor a cero y devuelve una nueva lista
     * @param minimo es el valor de aptitud para el criterio de filtrado
     * @return Nueva lista de supervivientes filtrados
     */
    public List<Superviviente> obtenerDisponiblesConAptitudMinima(int minimo){
        if(minimo < 0){
            throw new IllegalArgumentException("El valor de aptitud no puede ser nulo");
        }
        List<Superviviente> filtrados = new ArrayList<>();
        
        for(Superviviente superviviente : supervivientes){
            if(superviviente.isDisponible() && superviviente.calcularAptitud()>= minimo){
                filtrados.add(superviviente);
            }
        }
        return filtrados;
    }   
}
