package p2_pp_capozzoli26;

/**
 * @author Paula Capozzoli
 */
public interface Asignable {
    String asignar(String tarea);
}
